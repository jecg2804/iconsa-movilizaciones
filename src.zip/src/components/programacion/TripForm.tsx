'use client'

import { useState, useEffect, useCallback } from 'react'
import { Select, type SelectOption } from '@/components/ui/Select'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import type { TripInput } from '@/hooks/useTrips'

type TripFormMode = 'create' | 'edit' | 'readonly'

interface TripFormProps {
  mode: TripFormMode
  initialData?: {
    tripId?: string | null
    scheduledDate: string
    driverId: string | null
    vehicleId: string | null
    trailerId: string | null
    rateId: string | null
    cost: number | null
    attPermit: boolean
    escort: boolean
    notes: string | null
    isExternal: boolean
    status?: string
    confirmationCode?: string | null
  }
  /** Conductores disponibles para el dropdown */
  drivers: SelectOption[]
  /** Vehiculos (cabezales) disponibles para el dropdown */
  vehicles: SelectOption[]
  /** Remolques disponibles para el dropdown */
  trailers: SelectOption[]
  /**
   * Tarifas disponibles para el dropdown.
   * sublabel debe contener el monto formateado, ej: "B/. 2,000.00"
   */
  rates: SelectOption[]
  /** Callback cada vez que cambian los datos del formulario */
  onChange: (data: TripInput) => void
  /**
   * Callback opcional para cuando cambia la tarifa seleccionada.
   * El padre puede usar esto para auto-rellenar el costo.
   */
  onRateChange?: (rateId: string | null) => void
}

function TripForm({
  mode,
  initialData,
  drivers,
  vehicles,
  trailers,
  rates,
  onChange,
  onRateChange,
}: TripFormProps) {
  // En modo edicion con viaje En Ruta, solo las notas son editables
  const isEnRuta = mode === 'edit' && initialData?.status === 'En Ruta'
  const isReadonly = mode === 'readonly'
  const fieldsDisabled = isReadonly || isEnRuta

  // --- Estado interno del formulario ---
  const [scheduledDate, setScheduledDate] = useState<string>(
    initialData?.scheduledDate ?? '',
  )
  const [driverId, setDriverId] = useState<string | null>(
    initialData?.driverId ?? null,
  )
  const [vehicleId, setVehicleId] = useState<string | null>(
    initialData?.vehicleId ?? null,
  )
  const [trailerId, setTrailerId] = useState<string | null>(
    initialData?.trailerId ?? null,
  )
  const [rateId, setRateId] = useState<string | null>(
    initialData?.rateId ?? null,
  )
  const [cost, setCost] = useState<string>(
    initialData?.cost != null ? String(initialData.cost) : '',
  )
  const [attPermit, setAttPermit] = useState<boolean>(
    initialData?.attPermit ?? false,
  )
  const [escort, setEscort] = useState<boolean>(
    initialData?.escort ?? false,
  )
  const [notes, setNotes] = useState<string>(initialData?.notes ?? '')
  const [isExternal, setIsExternal] = useState<boolean>(
    initialData?.isExternal ?? false,
  )

  // --- Propagar cambios al padre ---
  const propagate = useCallback(
    (overrides?: Partial<TripInput>) => {
      const data: TripInput = {
        scheduled_date: overrides?.scheduled_date ?? scheduledDate,
        driver_id: overrides?.driver_id !== undefined ? overrides.driver_id : driverId,
        vehicle_id: overrides?.vehicle_id !== undefined ? overrides.vehicle_id : vehicleId,
        trailer_id: overrides?.trailer_id !== undefined ? overrides.trailer_id : trailerId,
        rate_id: overrides?.rate_id !== undefined ? overrides.rate_id : rateId,
        cost: overrides?.cost !== undefined ? overrides.cost : (parseFloat(cost) || null),
        att_permit: overrides?.att_permit !== undefined ? overrides.att_permit : attPermit,
        escort: overrides?.escort !== undefined ? overrides.escort : escort,
        notes: overrides?.notes !== undefined ? overrides.notes : (notes.trim() || null),
        is_external: overrides?.is_external !== undefined ? overrides.is_external : isExternal,
      }
      onChange(data)
    },
    [scheduledDate, driverId, vehicleId, trailerId, rateId, cost, attPermit, escort, notes, isExternal, onChange],
  )

  // Propagar el estado inicial al montar
  useEffect(() => {
    propagate()
    // Solo en el montaje inicial
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // --- Handlers de cambio ---
  const handleDateChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value
      setScheduledDate(val)
      propagate({ scheduled_date: val })
    },
    [propagate],
  )

  const handleDriverChange = useCallback(
    (val: string | null) => {
      setDriverId(val)
      propagate({ driver_id: val })
    },
    [propagate],
  )

  const handleVehicleChange = useCallback(
    (val: string | null) => {
      setVehicleId(val)
      propagate({ vehicle_id: val })
    },
    [propagate],
  )

  const handleTrailerChange = useCallback(
    (val: string | null) => {
      setTrailerId(val)
      propagate({ trailer_id: val })
    },
    [propagate],
  )

  const handleRateChange = useCallback(
    (val: string | null) => {
      setRateId(val)
      // Notificar al padre para que auto-rellene el costo si lo desea
      onRateChange?.(val)
      propagate({ rate_id: val })
    },
    [propagate, onRateChange],
  )

  const handleCostChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value
      setCost(val)
      propagate({ cost: parseFloat(val) || null })
    },
    [propagate],
  )

  const handleAttPermitChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.checked
      setAttPermit(val)
      propagate({ att_permit: val })
    },
    [propagate],
  )

  const handleEscortChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.checked
      setEscort(val)
      propagate({ escort: val })
    },
    [propagate],
  )

  const handleNotesChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const val = e.target.value
      setNotes(val)
      propagate({ notes: val.trim() || null })
    },
    [propagate],
  )

  const handleExternalChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.checked
      setIsExternal(val)
      propagate({ is_external: val })
    },
    [propagate],
  )

  // Datos de visualizacion de la barra de identificacion
  const tripId = initialData?.tripId
  const status = initialData?.status
  const confirmationCode = initialData?.confirmationCode

  return (
    <div className="space-y-4">
      {/* Barra de identificacion */}
      <div className="flex flex-col gap-2 rounded-lg bg-gray-100 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        {/* ID del viaje */}
        <div className="flex items-center gap-3 flex-wrap">
          {tripId ? (
            <span className="text-lg font-bold font-mono text-navy">
              {tripId}
            </span>
          ) : (
            <span className="text-sm italic text-iconsa-gray">
              Se generara al guardar
            </span>
          )}

          {/* Badges de estado y permisos especiales */}
          {status && (
            <div className="flex items-center gap-2">
              <Badge variant="trip" label={status} />
              {attPermit && (
                <Badge
                  variant="custom"
                  label="ATT"
                  bg="bg-purple-100"
                  text="text-purple-800"
                />
              )}
              {escort && (
                <Badge
                  variant="custom"
                  label="Escolta"
                  bg="bg-orange-100"
                  text="text-orange-800"
                />
              )}
            </div>
          )}
        </div>

        {/* Codigo de confirmacion (solo en modo edicion o lectura si ya existe) */}
        {confirmationCode && (mode === 'edit' || mode === 'readonly') && (
          <div className="flex items-center gap-1.5 text-sm text-iconsa-gray">
            <span>Codigo:</span>
            <span className="font-mono font-bold text-gray-900 tracking-widest">
              {confirmationCode}
            </span>
          </div>
        )}
      </div>

      {/* Campos del formulario */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {/* Fecha Programada */}
        <Input
          label="Fecha Programada"
          type="date"
          value={scheduledDate}
          onChange={handleDateChange}
          disabled={fieldsDisabled}
        />

        {/* Conductor */}
        <Select
          label="Conductor"
          placeholder="Seleccionar conductor..."
          options={drivers}
          value={driverId}
          onChange={handleDriverChange}
          disabled={fieldsDisabled}
          searchable
        />

        {/* Vehiculo */}
        <Select
          label="Vehiculo (Cabezal)"
          placeholder="Seleccionar vehiculo..."
          options={vehicles}
          value={vehicleId}
          onChange={handleVehicleChange}
          disabled={fieldsDisabled}
          searchable
        />

        {/* Remolque */}
        <Select
          label="Remolque (opcional)"
          placeholder="Seleccionar remolque..."
          options={trailers}
          value={trailerId}
          onChange={handleTrailerChange}
          disabled={fieldsDisabled}
          searchable
        />

        {/* Tarifa */}
        <Select
          label="Tarifa de Movilizacion"
          placeholder="Seleccionar tarifa..."
          options={rates}
          value={rateId}
          onChange={handleRateChange}
          disabled={fieldsDisabled}
          searchable
        />

        {/* Costo */}
        <Input
          label="Costo (B/.)"
          type="number"
          step="0.01"
          min="0"
          value={cost}
          onChange={handleCostChange}
          disabled={fieldsDisabled}
          placeholder="0.00"
        />

        {/* Toggles: ATT Permit + Escolta + Externo — fila completa en mobile, columna par en desktop */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-6 md:col-span-2">
          {/* Requiere Permiso ATT */}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={attPermit}
              onChange={handleAttPermitChange}
              disabled={fieldsDisabled}
              className="rounded border-gray-300 text-navy focus:ring-navy disabled:cursor-not-allowed"
            />
            <span className="text-sm font-medium text-gray-700">
              Requiere Permiso ATT
            </span>
          </label>

          {/* Requiere Escolta */}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={escort}
              onChange={handleEscortChange}
              disabled={fieldsDisabled}
              className="rounded border-gray-300 text-navy focus:ring-navy disabled:cursor-not-allowed"
            />
            <span className="text-sm font-medium text-gray-700">
              Requiere Escolta
            </span>
          </label>

          {/* Viaje externo (conductor/empresa externa) */}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={isExternal}
              onChange={handleExternalChange}
              disabled={fieldsDisabled}
              className="rounded border-gray-300 text-navy focus:ring-navy disabled:cursor-not-allowed"
            />
            <span className="text-sm font-medium text-gray-700">
              Viaje externo
            </span>
          </label>
        </div>

        {/* Notas — ancho completo. En modo En Ruta, este campo SI es editable */}
        <div className="md:col-span-2">
          <label
            htmlFor="trip-notes"
            className="mb-1 block text-sm font-medium text-gray-700"
          >
            Notas
          </label>
          <textarea
            id="trip-notes"
            value={notes}
            onChange={handleNotesChange}
            // Las notas son editables incluso en modo En Ruta
            disabled={isReadonly}
            placeholder="Observaciones operativas del viaje (opcional)"
            rows={3}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm placeholder:text-gray-400 focus:border-iconsa-blue focus:outline-none focus:ring-1 focus:ring-iconsa-blue disabled:bg-gray-50 disabled:text-gray-500"
          />
        </div>
      </div>
    </div>
  )
}

export { TripForm }
export type { TripFormProps, TripFormMode }
